import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { email, password } = await request.json()

    // Check if the email is the admin email
    if (email === "lecleccomp@gmail.com") {
      // In a real app, you would verify the password against a hashed version in a database
      // For demo purposes, we're just checking if the password exists
      if (password && password.length > 0) {
        return NextResponse.json({
          success: true,
          user: {
            email: "lecleccomp@gmail.com",
            role: "admin",
            name: "YF MATH Admin",
          },
          message: "Login successful",
        })
      }
    }

    // If not the admin email or password is incorrect
    return NextResponse.json(
      {
        success: false,
        message: "Invalid credentials",
      },
      { status: 401 },
    )
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        message: "Authentication failed",
      },
      { status: 500 },
    )
  }
}
