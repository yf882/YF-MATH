"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ArrowLeft, Calculator } from "lucide-react"
import Link from "next/link"

export default function CalculatorPage() {
  const [display, setDisplay] = useState("0")
  const [previousValue, setPreviousValue] = useState<number | null>(null)
  const [operation, setOperation] = useState<string | null>(null)
  const [waitingForOperand, setWaitingForOperand] = useState(false)

  const inputNumber = (num: string) => {
    if (waitingForOperand) {
      setDisplay(num)
      setWaitingForOperand(false)
    } else {
      setDisplay(display === "0" ? num : display + num)
    }
  }

  const inputOperation = (nextOperation: string) => {
    const inputValue = Number.parseFloat(display)

    if (previousValue === null) {
      setPreviousValue(inputValue)
    } else if (operation) {
      const currentValue = previousValue || 0
      const newValue = calculate(currentValue, inputValue, operation)

      setDisplay(String(newValue))
      setPreviousValue(newValue)
    }

    setWaitingForOperand(true)
    setOperation(nextOperation)
  }

  const calculate = (firstValue: number, secondValue: number, operation: string) => {
    switch (operation) {
      case "+":
        return firstValue + secondValue
      case "-":
        return firstValue - secondValue
      case "×":
        return firstValue * secondValue
      case "÷":
        return firstValue / secondValue
      case "=":
        return secondValue
      default:
        return secondValue
    }
  }

  const performCalculation = () => {
    const inputValue = Number.parseFloat(display)

    if (previousValue !== null && operation) {
      const newValue = calculate(previousValue, inputValue, operation)
      setDisplay(String(newValue))
      setPreviousValue(null)
      setOperation(null)
      setWaitingForOperand(true)
    }
  }

  const clear = () => {
    setDisplay("0")
    setPreviousValue(null)
    setOperation(null)
    setWaitingForOperand(false)
  }

  const clearEntry = () => {
    setDisplay("0")
  }

  const inputDecimal = () => {
    if (waitingForOperand) {
      setDisplay("0.")
      setWaitingForOperand(false)
    } else if (display.indexOf(".") === -1) {
      setDisplay(display + ".")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <div className="flex items-center space-x-2">
                <Calculator className="h-6 w-6 text-blue-600" />
                <span className="text-xl font-bold text-gray-900">YF MATH Calculator</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-md mx-auto">
          <Card className="shadow-xl">
            <CardHeader>
              <CardTitle className="text-center">Scientific Calculator</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Display */}
              <div className="bg-gray-900 text-white p-4 rounded-lg">
                <Input
                  value={display}
                  readOnly
                  className="text-right text-2xl font-mono bg-transparent border-none text-white"
                />
              </div>

              {/* Buttons */}
              <div className="grid grid-cols-4 gap-2">
                {/* Row 1 */}
                <Button variant="outline" onClick={clear} className="h-12 bg-transparent">
                  AC
                </Button>
                <Button variant="outline" onClick={clearEntry} className="h-12 bg-transparent">
                  CE
                </Button>
                <Button variant="outline" onClick={() => inputOperation("÷")} className="h-12">
                  ÷
                </Button>
                <Button variant="outline" onClick={() => inputOperation("×")} className="h-12">
                  ×
                </Button>

                {/* Row 2 */}
                <Button variant="outline" onClick={() => inputNumber("7")} className="h-12">
                  7
                </Button>
                <Button variant="outline" onClick={() => inputNumber("8")} className="h-12">
                  8
                </Button>
                <Button variant="outline" onClick={() => inputNumber("9")} className="h-12">
                  9
                </Button>
                <Button variant="outline" onClick={() => inputOperation("-")} className="h-12">
                  -
                </Button>

                {/* Row 3 */}
                <Button variant="outline" onClick={() => inputNumber("4")} className="h-12">
                  4
                </Button>
                <Button variant="outline" onClick={() => inputNumber("5")} className="h-12">
                  5
                </Button>
                <Button variant="outline" onClick={() => inputNumber("6")} className="h-12">
                  6
                </Button>
                <Button variant="outline" onClick={() => inputOperation("+")} className="h-12">
                  +
                </Button>

                {/* Row 4 */}
                <Button variant="outline" onClick={() => inputNumber("1")} className="h-12">
                  1
                </Button>
                <Button variant="outline" onClick={() => inputNumber("2")} className="h-12">
                  2
                </Button>
                <Button variant="outline" onClick={() => inputNumber("3")} className="h-12">
                  3
                </Button>
                <Button onClick={performCalculation} className="h-12 bg-blue-600 hover:bg-blue-700 row-span-2">
                  =
                </Button>

                {/* Row 5 */}
                <Button variant="outline" onClick={() => inputNumber("0")} className="h-12 col-span-2">
                  0
                </Button>
                <Button variant="outline" onClick={inputDecimal} className="h-12 bg-transparent">
                  .
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
