"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, BookOpen, Play, CheckCircle, Clock, Star, Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import Link from "next/link"

export default function LessonsPage() {
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [searchQuery, setSearchQuery] = useState("")
  const [completedLessons, setCompletedLessons] = useState<number[]>([])

  useEffect(() => {
    // Load completed lessons from localStorage
    const saved = localStorage.getItem("yfmath_completed_lessons")
    if (saved) {
      try {
        setCompletedLessons(JSON.parse(saved))
      } catch (e) {
        console.error("Error loading completed lessons", e)
      }
    }
  }, [])

  const categories = [
    { id: "all", name: "All Lessons", count: 24 },
    { id: "algebra", name: "Algebra", count: 8 },
    { id: "geometry", name: "Geometry", count: 6 },
    { id: "calculus", name: "Calculus", count: 5 },
    { id: "statistics", name: "Statistics", count: 5 },
  ]

  const lessons = [
    {
      id: 1,
      title: "Introduction to Linear Equations",
      description: "Learn the fundamentals of solving linear equations step by step.",
      category: "algebra",
      difficulty: "Beginner",
      duration: "15 min",
      rating: 4.8,
      topics: ["Variables", "Coefficients", "Solving for x"],
    },
    {
      id: 2,
      title: "Quadratic Equations and Formulas",
      description: "Master quadratic equations using factoring, completing the square, and the quadratic formula.",
      category: "algebra",
      difficulty: "Intermediate",
      duration: "25 min",
      rating: 4.9,
      topics: ["Factoring", "Quadratic Formula", "Discriminant"],
    },
    {
      id: 3,
      title: "Basic Geometric Shapes",
      description: "Explore properties of triangles, circles, and polygons.",
      category: "geometry",
      difficulty: "Beginner",
      duration: "20 min",
      rating: 4.7,
      topics: ["Triangles", "Circles", "Area", "Perimeter"],
    },
    {
      id: 4,
      title: "Pythagorean Theorem",
      description: "Understanding and applying the Pythagorean theorem in real-world problems.",
      category: "geometry",
      difficulty: "Beginner",
      duration: "18 min",
      rating: 4.8,
      topics: ["Right Triangles", "Distance", "Applications"],
    },
    {
      id: 5,
      title: "Introduction to Derivatives",
      description: "Learn the concept of derivatives and basic differentiation rules.",
      category: "calculus",
      difficulty: "Advanced",
      duration: "30 min",
      rating: 4.6,
      topics: ["Limits", "Differentiation", "Chain Rule"],
    },
    {
      id: 6,
      title: "Descriptive Statistics",
      description: "Calculate and interpret mean, median, mode, and standard deviation.",
      category: "statistics",
      difficulty: "Intermediate",
      duration: "22 min",
      rating: 4.7,
      topics: ["Mean", "Median", "Standard Deviation"],
    },
    {
      id: 7,
      title: "Systems of Linear Equations",
      description: "Solve systems of linear equations using substitution and elimination methods.",
      category: "algebra",
      difficulty: "Intermediate",
      duration: "28 min",
      rating: 4.5,
      topics: ["Systems", "Substitution", "Elimination"],
    },
    {
      id: 8,
      title: "Introduction to Trigonometry",
      description: "Learn the basics of trigonometric functions and their applications.",
      category: "geometry",
      difficulty: "Intermediate",
      duration: "35 min",
      rating: 4.6,
      topics: ["Sine", "Cosine", "Tangent", "Angles"],
    },
  ]

  const filteredLessons = lessons
    .filter((lesson) => selectedCategory === "all" || lesson.category === selectedCategory)
    .filter(
      (lesson) =>
        searchQuery === "" ||
        lesson.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        lesson.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        lesson.topics.some((topic) => topic.toLowerCase().includes(searchQuery.toLowerCase())),
    )

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner":
        return "bg-green-100 text-green-800"
      case "Intermediate":
        return "bg-yellow-100 text-yellow-800"
      case "Advanced":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const completedCount = completedLessons.length
  const totalLessons = lessons.length
  const progressPercentage = totalLessons > 0 ? (completedCount / totalLessons) * 100 : 0

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <div className="flex items-center space-x-2">
                <BookOpen className="h-6 w-6 text-blue-600" />
                <span className="text-xl font-bold text-gray-900">YF MATH Lessons</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Progress Overview */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Your Learning Progress</CardTitle>
            <CardDescription>Keep up the great work! You're making excellent progress.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600 mb-2">{completedCount}</div>
                <div className="text-sm text-gray-600">Lessons Completed</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600 mb-2">{totalLessons - completedCount}</div>
                <div className="text-sm text-gray-600">Lessons Remaining</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600 mb-2">4.7</div>
                <div className="text-sm text-gray-600">Average Rating</div>
              </div>
            </div>
            <div className="mt-6">
              <div className="flex justify-between text-sm mb-2">
                <span>Overall Progress</span>
                <span>{Math.round(progressPercentage)}%</span>
              </div>
              <Progress value={progressPercentage} className="h-2" />
            </div>
          </CardContent>
        </Card>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Categories Sidebar */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Categories</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {categories.map((category) => (
                  <Button
                    key={category.id}
                    variant={selectedCategory === category.id ? "default" : "ghost"}
                    className="w-full justify-between"
                    onClick={() => setSelectedCategory(category.id)}
                  >
                    <span>{category.name}</span>
                    <Badge variant="secondary">{category.count}</Badge>
                  </Button>
                ))}
              </CardContent>
            </Card>

            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="text-lg">Learning Path</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Beginner</span>
                    <span>4/8 completed</span>
                  </div>
                  <Progress value={50} className="h-2" />
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Intermediate</span>
                    <span>2/10 completed</span>
                  </div>
                  <Progress value={20} className="h-2" />
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Advanced</span>
                    <span>0/6 completed</span>
                  </div>
                  <Progress value={0} className="h-2" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Lessons Grid */}
          <div className="lg:col-span-3">
            <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
              <h1 className="text-2xl font-bold text-gray-900">
                {selectedCategory === "all" ? "All Lessons" : categories.find((c) => c.id === selectedCategory)?.name}
              </h1>

              <div className="relative w-full md:w-auto">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search lessons..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 w-full md:w-[300px]"
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              {filteredLessons.length > 0 ? (
                filteredLessons.map((lesson) => (
                  <Card key={lesson.id} className="hover:shadow-lg transition-all duration-300">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-lg mb-2">{lesson.title}</CardTitle>
                          <CardDescription className="mb-3">{lesson.description}</CardDescription>
                        </div>
                        {completedLessons.includes(lesson.id) && (
                          <CheckCircle className="h-6 w-6 text-green-600 flex-shrink-0" />
                        )}
                      </div>

                      <div className="flex flex-wrap gap-2 mb-3">
                        <Badge className={getDifficultyColor(lesson.difficulty)}>{lesson.difficulty}</Badge>
                        <Badge variant="outline" className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {lesson.duration}
                        </Badge>
                        <Badge variant="outline" className="flex items-center gap-1">
                          <Star className="h-3 w-3 fill-current text-yellow-500" />
                          {lesson.rating}
                        </Badge>
                      </div>

                      <div className="mb-4">
                        <div className="text-sm font-medium text-gray-700 mb-2">Topics covered:</div>
                        <div className="flex flex-wrap gap-1">
                          {lesson.topics.map((topic, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {topic}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </CardHeader>

                    <CardContent>
                      <Link href={`/lessons/${lesson.id}`}>
                        <Button className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                          <Play className="h-4 w-4 mr-2" />
                          {completedLessons.includes(lesson.id) ? "Review Lesson" : "Start Lesson"}
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="col-span-2 text-center py-12">
                  <BookOpen className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No lessons found</h3>
                  <p className="text-gray-600 mb-4">We couldn't find any lessons matching your search criteria.</p>
                  <Button
                    onClick={() => {
                      setSearchQuery("")
                      setSelectedCategory("all")
                    }}
                  >
                    Clear filters
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
