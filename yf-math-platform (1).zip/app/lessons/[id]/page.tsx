"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, ArrowRight, BookOpen, CheckCircle, ThumbsUp, ThumbsDown, MessageSquare } from "lucide-react"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import Link from "next/link"

export default function LessonDetailPage({ params }: { params: { id: string } }) {
  const { toast } = useToast()
  const [currentStep, setCurrentStep] = useState(0)
  const [completed, setCompleted] = useState(false)
  const [showFeedback, setShowFeedback] = useState(false)
  const [feedbackText, setFeedbackText] = useState("")
  const [isHelpful, setIsHelpful] = useState<boolean | null>(null)
  const [notes, setNotes] = useState("")

  // Get lesson data based on ID
  const lessonId = Number.parseInt(params.id)

  const lessons = [
    {
      id: 1,
      title: "Introduction to Linear Equations",
      description: "Learn the fundamentals of solving linear equations step by step.",
      duration: "15 min",
      steps: [
        {
          title: "What is a Linear Equation?",
          content: `A linear equation is an algebraic equation where each term is either a constant or the product of a constant and a single variable.

The general form of a linear equation in one variable is:
**ax + b = c**

Where:
- a, b, and c are constants
- x is the variable
- a ≠ 0

Examples of linear equations:
- 2x + 3 = 7
- 5x - 2 = 13
- x + 4 = 10`,
          formula: "ax + b = c",
        },
        {
          title: "Solving Linear Equations",
          content: `To solve a linear equation, we need to isolate the variable (usually x) on one side of the equation.

**Steps to solve:**
1. Simplify both sides of the equation
2. Move all terms with the variable to one side
3. Move all constant terms to the other side
4. Divide by the coefficient of the variable

**Example:** Solve 2x + 3 = 7
1. Subtract 3 from both sides: 2x = 4
2. Divide both sides by 2: x = 2`,
          formula: "2x + 3 = 7 → x = 2",
        },
        {
          title: "Practice Problem",
          content: `Let's solve this equation step by step:
**3x - 5 = 16**

Step 1: Add 5 to both sides
3x - 5 + 5 = 16 + 5
3x = 21

Step 2: Divide both sides by 3
3x ÷ 3 = 21 ÷ 3
x = 7

**Solution: x = 7**

Let's verify: 3(7) - 5 = 21 - 5 = 16 ✓`,
          formula: "3x - 5 = 16 → x = 7",
          interactive: true,
        },
        {
          title: "Key Takeaways",
          content: `**Remember these important points:**

1. **Balance Principle**: Whatever you do to one side of the equation, you must do to the other side

2. **Inverse Operations**: Use inverse operations to isolate the variable:
   - Addition ↔ Subtraction
   - Multiplication ↔ Division

3. **Check Your Answer**: Always substitute your solution back into the original equation

4. **Common Mistakes to Avoid**:
   - Forgetting to apply operations to both sides
   - Sign errors when moving terms
   - Not simplifying completely`,
          formula: "Always verify: substitute x back into the original equation",
        },
      ],
    },
    {
      id: 2,
      title: "Quadratic Equations and Formulas",
      description: "Master quadratic equations using factoring, completing the square, and the quadratic formula.",
      duration: "25 min",
      steps: [
        {
          title: "Understanding Quadratic Equations",
          content: `A quadratic equation is a second-degree polynomial equation in a single variable x.

The standard form of a quadratic equation is:
**ax² + bx + c = 0**

Where:
- a, b, and c are constants
- a ≠ 0 (otherwise it would be a linear equation)

Examples of quadratic equations:
- x² + 5x + 6 = 0
- 2x² - 7x + 3 = 0
- x² - 9 = 0`,
          formula: "ax² + bx + c = 0",
        },
        {
          title: "Solving by Factoring",
          content: `When possible, factoring is the simplest method to solve quadratic equations.

**Steps to solve by factoring:**
1. Make sure the equation is in standard form (ax² + bx + c = 0)
2. Factor the left side into (px + q)(rx + s)
3. Set each factor equal to zero and solve for x

**Example:** Solve x² + 5x + 6 = 0
1. Factor: x² + 5x + 6 = (x + 2)(x + 3) = 0
2. Set each factor to zero:
   x + 2 = 0 → x = -2
   x + 3 = 0 → x = -3
3. Solutions: x = -2 or x = -3`,
          formula: "x² + 5x + 6 = 0 → (x + 2)(x + 3) = 0 → x = -2 or x = -3",
        },
        {
          title: "The Quadratic Formula",
          content: `When factoring is difficult or impossible, use the quadratic formula:

**Quadratic Formula:**
x = (-b ± √(b² - 4ac)) / 2a

Where a, b, and c are the coefficients from the standard form ax² + bx + c = 0.

**Example:** Solve 2x² - 7x + 3 = 0
1. Identify a = 2, b = -7, c = 3
2. Substitute into the formula:
   x = (-(-7) ± √((-7)² - 4(2)(3))) / 2(2)
   x = (7 ± √(49 - 24)) / 4
   x = (7 ± √25) / 4
   x = (7 ± 5) / 4
3. Solutions: x = 3 or x = 1/2`,
          formula: "x = (-b ± √(b² - 4ac)) / 2a",
          interactive: true,
        },
        {
          title: "The Discriminant",
          content: `The discriminant (b² - 4ac) tells us about the nature of the solutions:

- If b² - 4ac > 0: Two distinct real solutions
- If b² - 4ac = 0: One real solution (repeated root)
- If b² - 4ac < 0: Two complex solutions (no real solutions)

**Example:** For 2x² - 7x + 3 = 0
Discriminant = (-7)² - 4(2)(3) = 49 - 24 = 25 > 0
Therefore, this equation has two distinct real solutions.`,
          formula: "Discriminant = b² - 4ac",
        },
      ],
    },
  ]

  const lesson = lessons.find((l) => l.id === lessonId) || lessons[0]

  // Save notes to localStorage
  useEffect(() => {
    const savedNotes = localStorage.getItem(`yfmath_notes_lesson_${lessonId}`)
    if (savedNotes) {
      setNotes(savedNotes)
    }
  }, [lessonId])

  const saveNotes = () => {
    localStorage.setItem(`yfmath_notes_lesson_${lessonId}`, notes)
    toast({
      title: "Notes saved",
      description: "Your notes have been saved successfully",
    })
  }

  const nextStep = () => {
    if (currentStep < lesson.steps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      setCompleted(true)
      // Mark lesson as completed in localStorage
      const completedLessons = JSON.parse(localStorage.getItem("yfmath_completed_lessons") || "[]")
      if (!completedLessons.includes(lessonId)) {
        completedLessons.push(lessonId)
        localStorage.setItem("yfmath_completed_lessons", JSON.stringify(completedLessons))
      }
    }
  }

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const submitFeedback = () => {
    toast({
      title: "Feedback submitted",
      description: "Thank you for your feedback!",
    })
    setShowFeedback(false)
  }

  const progress = ((currentStep + 1) / lesson.steps.length) * 100

  if (completed) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <Card className="max-w-md mx-auto text-center">
          <CardHeader>
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
            <CardTitle>Lesson Complete!</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-gray-600">Congratulations! You've successfully completed "{lesson.title}".</p>

            {!showFeedback ? (
              <div className="space-y-4">
                <div className="bg-blue-50 p-4 rounded-lg text-center">
                  <p className="text-blue-800 font-medium mb-2">Was this lesson helpful?</p>
                  <div className="flex justify-center gap-4">
                    <Button
                      variant="outline"
                      className="flex items-center gap-2 bg-transparent"
                      onClick={() => {
                        setIsHelpful(true)
                        setShowFeedback(true)
                      }}
                    >
                      <ThumbsUp className="h-4 w-4" />
                      Yes
                    </Button>
                    <Button
                      variant="outline"
                      className="flex items-center gap-2 bg-transparent"
                      onClick={() => {
                        setIsHelpful(false)
                        setShowFeedback(true)
                      }}
                    >
                      <ThumbsDown className="h-4 w-4" />
                      No
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Link href="/lessons">
                    <Button className="w-full">Back to Lessons</Button>
                  </Link>
                  <Link href="/tools/equation-solver">
                    <Button variant="outline" className="w-full bg-transparent">
                      Practice with Equation Solver
                    </Button>
                  </Link>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <p className="text-sm text-gray-600">
                  {isHelpful
                    ? "Great! Please let us know what you liked about this lesson."
                    : "We're sorry to hear that. Please let us know how we can improve this lesson."}
                </p>
                <Textarea
                  placeholder="Your feedback..."
                  value={feedbackText}
                  onChange={(e) => setFeedbackText(e.target.value)}
                  rows={4}
                />
                <div className="flex gap-2">
                  <Button onClick={submitFeedback} className="flex-1">
                    Submit Feedback
                  </Button>
                  <Button variant="outline" onClick={() => setShowFeedback(false)}>
                    Skip
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/lessons">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <div className="flex items-center space-x-2">
                <BookOpen className="h-6 w-6 text-blue-600" />
                <span className="text-xl font-bold text-gray-900">{lesson.title}</span>
              </div>
            </div>
            <div className="text-sm text-gray-600">
              Step {currentStep + 1} of {lesson.steps.length}
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Progress Bar */}
        <Card className="mb-8">
          <CardContent className="pt-6">
            <div className="flex justify-between text-sm mb-2">
              <span>Progress</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <Progress value={progress} className="h-2" />
          </CardContent>
        </Card>

        {/* Lesson Content */}
        <div className="max-w-4xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="md:col-span-2">
              <Card className="mb-8">
                <CardHeader>
                  <CardTitle className="text-2xl">{lesson.steps[currentStep].title}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="prose max-w-none">
                    {lesson.steps[currentStep].content.split("\n").map((paragraph, index) => {
                      if (paragraph.startsWith("**") && paragraph.endsWith("**")) {
                        return (
                          <h3 key={index} className="text-lg font-semibold text-gray-900 mt-4 mb-2">
                            {paragraph.slice(2, -2)}
                          </h3>
                        )
                      }
                      if (paragraph.startsWith("- ")) {
                        return (
                          <li key={index} className="text-gray-700 ml-4">
                            {paragraph.slice(2)}
                          </li>
                        )
                      }
                      if (paragraph.trim()) {
                        return (
                          <p key={index} className="text-gray-700 leading-relaxed">
                            {paragraph}
                          </p>
                        )
                      }
                      return <br key={index} />
                    })}
                  </div>

                  {lesson.steps[currentStep].formula && (
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <div className="text-center">
                        <div className="text-sm font-medium text-blue-800 mb-2">Key Formula:</div>
                        <div className="text-xl font-mono font-bold text-blue-900">
                          {lesson.steps[currentStep].formula}
                        </div>
                      </div>
                    </div>
                  )}

                  {lesson.steps[currentStep].interactive && (
                    <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                      <div className="text-center">
                        <div className="text-sm font-medium text-green-800 mb-2">Interactive Practice:</div>
                        <p className="text-green-700 mb-4">Try solving this problem on your own!</p>
                        <Button className="bg-green-600 hover:bg-green-700">Open Practice Tool</Button>
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-center gap-2 pt-4">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex items-center gap-1 bg-transparent"
                      onClick={() => {
                        toast({
                          title: "Help requested",
                          description: "A tutor will respond to your question soon.",
                        })
                      }}
                    >
                      <MessageSquare className="h-4 w-4" />
                      Ask for Help
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Navigation */}
              <div className="flex justify-between">
                <Button
                  onClick={prevStep}
                  disabled={currentStep === 0}
                  variant="outline"
                  className="flex items-center gap-2 bg-transparent"
                >
                  <ArrowLeft className="h-4 w-4" />
                  Previous
                </Button>
                <Button
                  onClick={nextStep}
                  className="flex items-center gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                >
                  {currentStep === lesson.steps.length - 1 ? (
                    <>
                      Complete Lesson
                      <CheckCircle className="h-4 w-4" />
                    </>
                  ) : (
                    <>
                      Next
                      <ArrowRight className="h-4 w-4" />
                    </>
                  )}
                </Button>
              </div>
            </div>

            {/* Notes Section */}
            <div className="md:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Your Notes</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Textarea
                    placeholder="Take notes here..."
                    className="min-h-[300px]"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                  />
                  <Button onClick={saveNotes} className="w-full">
                    Save Notes
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
