"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, PieChart, Calculator, BarChart3 } from "lucide-react"
import Link from "next/link"

interface StatResults {
  mean: number
  median: number
  mode: number[]
  range: number
  variance: number
  standardDeviation: number
  count: number
  sum: number
  min: number
  max: number
}

export default function StatisticsPage() {
  const [dataInput, setDataInput] = useState("1, 2, 3, 4, 5, 5, 6, 7, 8, 9, 10")
  const [results, setResults] = useState<StatResults | null>(null)

  const parseData = (input: string): number[] => {
    return input
      .split(/[,\s\n]+/)
      .map((item) => Number.parseFloat(item.trim()))
      .filter((num) => !isNaN(num))
  }

  const calculateStatistics = () => {
    const data = parseData(dataInput)

    if (data.length === 0) {
      alert("Please enter valid numbers")
      return
    }

    // Sort data for median calculation
    const sortedData = [...data].sort((a, b) => a - b)

    // Mean
    const sum = data.reduce((acc, val) => acc + val, 0)
    const mean = sum / data.length

    // Median
    const median =
      sortedData.length % 2 === 0
        ? (sortedData[sortedData.length / 2 - 1] + sortedData[sortedData.length / 2]) / 2
        : sortedData[Math.floor(sortedData.length / 2)]

    // Mode
    const frequency: { [key: number]: number } = {}
    data.forEach((num) => {
      frequency[num] = (frequency[num] || 0) + 1
    })
    const maxFreq = Math.max(...Object.values(frequency))
    const mode = Object.keys(frequency)
      .filter((key) => frequency[Number(key)] === maxFreq)
      .map(Number)

    // Range
    const min = Math.min(...data)
    const max = Math.max(...data)
    const range = max - min

    // Variance
    const variance = data.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / data.length

    // Standard Deviation
    const standardDeviation = Math.sqrt(variance)

    setResults({
      mean,
      median,
      mode,
      range,
      variance,
      standardDeviation,
      count: data.length,
      sum,
      min,
      max,
    })
  }

  const clearData = () => {
    setDataInput("")
    setResults(null)
  }

  const loadSampleData = (sample: string) => {
    const samples = {
      grades: "85, 92, 78, 96, 88, 76, 94, 89, 82, 91",
      heights: "165, 170, 168, 172, 169, 171, 167, 173, 166, 174",
      sales: "1200, 1350, 1100, 1450, 1300, 1250, 1400, 1150, 1500, 1320",
    }
    setDataInput(samples[sample as keyof typeof samples])
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/tools">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <div className="flex items-center space-x-2">
                <PieChart className="h-6 w-6 text-blue-600" />
                <span className="text-xl font-bold text-gray-900">YF MATH Statistics Calculator</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Input Section */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-5 w-5" />
                  Data Input
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="data">Enter your data (comma or space separated):</Label>
                  <Textarea
                    id="data"
                    value={dataInput}
                    onChange={(e) => setDataInput(e.target.value)}
                    placeholder="1, 2, 3, 4, 5..."
                    rows={4}
                    className="font-mono"
                  />
                </div>

                <div className="flex gap-2">
                  <Button onClick={calculateStatistics} className="flex-1 bg-blue-600 hover:bg-blue-700">
                    Calculate Statistics
                  </Button>
                  <Button onClick={clearData} variant="outline">
                    Clear
                  </Button>
                </div>

                {/* Sample Data */}
                <div className="mt-6">
                  <Label className="text-sm font-medium">Sample datasets:</Label>
                  <div className="mt-2 space-y-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => loadSampleData("grades")}
                      className="w-full justify-start text-sm"
                    >
                      📊 Student Grades
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => loadSampleData("heights")}
                      className="w-full justify-start text-sm"
                    >
                      📏 Heights (cm)
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => loadSampleData("sales")}
                      className="w-full justify-start text-sm"
                    >
                      💰 Monthly Sales
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Formulas Reference */}
            <Card>
              <CardHeader>
                <CardTitle>Statistical Formulas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3 text-sm">
                  <div>
                    <strong>Mean (Average):</strong>
                    <div className="font-mono bg-gray-100 p-2 rounded mt-1">μ = Σx / n</div>
                  </div>
                  <div>
                    <strong>Variance:</strong>
                    <div className="font-mono bg-gray-100 p-2 rounded mt-1">σ² = Σ(x - μ)² / n</div>
                  </div>
                  <div>
                    <strong>Standard Deviation:</strong>
                    <div className="font-mono bg-gray-100 p-2 rounded mt-1">σ = √(σ²)</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Results Section */}
          <div className="space-y-6">
            {results ? (
              <>
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="h-5 w-5" />
                      Statistical Results
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-blue-50 p-4 rounded-lg">
                        <div className="text-sm text-blue-600 font-medium">Mean</div>
                        <div className="text-2xl font-bold text-blue-900">{results.mean.toFixed(2)}</div>
                      </div>
                      <div className="bg-green-50 p-4 rounded-lg">
                        <div className="text-sm text-green-600 font-medium">Median</div>
                        <div className="text-2xl font-bold text-green-900">{results.median.toFixed(2)}</div>
                      </div>
                      <div className="bg-purple-50 p-4 rounded-lg">
                        <div className="text-sm text-purple-600 font-medium">Mode</div>
                        <div className="text-2xl font-bold text-purple-900">
                          {results.mode.length === 1 ? results.mode[0] : results.mode.join(", ")}
                        </div>
                      </div>
                      <div className="bg-orange-50 p-4 rounded-lg">
                        <div className="text-sm text-orange-600 font-medium">Range</div>
                        <div className="text-2xl font-bold text-orange-900">{results.range.toFixed(2)}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Detailed Statistics</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="font-medium">Count:</span>
                        <span>{results.count}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Sum:</span>
                        <span>{results.sum.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Minimum:</span>
                        <span>{results.min}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Maximum:</span>
                        <span>{results.max}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Variance:</span>
                        <span>{results.variance.toFixed(4)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Standard Deviation:</span>
                        <span>{results.standardDeviation.toFixed(4)}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Data Visualization</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {/* Simple histogram representation */}
                      <div>
                        <div className="text-sm font-medium mb-2">Data Distribution:</div>
                        <div className="space-y-1">
                          {parseData(dataInput)
                            .sort((a, b) => a - b)
                            .reduce((acc: { value: number; count: number }[], val) => {
                              const existing = acc.find((item) => item.value === val)
                              if (existing) {
                                existing.count++
                              } else {
                                acc.push({ value: val, count: 1 })
                              }
                              return acc
                            }, [])
                            .map((item, index) => (
                              <div key={index} className="flex items-center gap-2">
                                <span className="w-12 text-sm">{item.value}:</span>
                                <div className="flex-1 bg-gray-200 rounded-full h-4">
                                  <div
                                    className="bg-blue-600 h-4 rounded-full"
                                    style={{
                                      width: `${
                                        (item.count /
                                          Math.max(
                                            ...parseData(dataInput)
                                              .reduce((acc: { value: number; count: number }[], val) => {
                                                const existing = acc.find((item) => item.value === val)
                                                if (existing) {
                                                  existing.count++
                                                } else {
                                                  acc.push({ value: val, count: 1 })
                                                }
                                                return acc
                                              }, [])
                                              .map((i) => i.count),
                                          )) *
                                        100
                                      }%`,
                                    }}
                                  />
                                </div>
                                <span className="w-8 text-sm">{item.count}</span>
                              </div>
                            ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </>
            ) : (
              <Card>
                <CardContent className="text-center py-12">
                  <PieChart className="h-16 w-16 mx-auto mb-4 text-gray-400" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No Data Yet</h3>
                  <p className="text-gray-600">
                    Enter your data in the input field and click "Calculate Statistics" to see the results.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
