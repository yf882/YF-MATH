"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ArrowLeft, BarChart3, Trash2, Eye, EyeOff } from "lucide-react"
import Link from "next/link"

interface GraphFunction {
  id: string
  expression: string
  color: string
  visible: boolean
}

export default function GraphingPage() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [functions, setFunctions] = useState<GraphFunction[]>([
    { id: "1", expression: "x^2", color: "#3b82f6", visible: true },
    { id: "2", expression: "2*x + 1", color: "#ef4444", visible: true },
  ])
  const [newFunction, setNewFunction] = useState("")
  const [scale, setScale] = useState(20)
  const [centerX, setCenterX] = useState(0)
  const [centerY, setCenterY] = useState(0)

  const colors = ["#3b82f6", "#ef4444", "#10b981", "#f59e0b", "#8b5cf6", "#06b6d4"]

  useEffect(() => {
    drawGraph()
  }, [functions, scale, centerX, centerY])

  const evaluateExpression = (expression: string, x: number): number => {
    try {
      // Simple expression evaluator for basic functions
      const expr = expression
        .replace(/\^/g, "**")
        .replace(/x/g, x.toString())
        .replace(/sin/g, "Math.sin")
        .replace(/cos/g, "Math.cos")
        .replace(/tan/g, "Math.tan")
        .replace(/log/g, "Math.log10")
        .replace(/ln/g, "Math.log")
        .replace(/sqrt/g, "Math.sqrt")
        .replace(/abs/g, "Math.abs")
        .replace(/pi/g, "Math.PI")
        .replace(/e/g, "Math.E")

      return eval(expr)
    } catch {
      return Number.NaN
    }
  }

  const drawGraph = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const width = canvas.width
    const height = canvas.height

    // Clear canvas
    ctx.clearRect(0, 0, width, height)

    // Draw grid
    ctx.strokeStyle = "#e5e7eb"
    ctx.lineWidth = 1

    // Vertical grid lines
    for (let x = 0; x < width; x += scale) {
      ctx.beginPath()
      ctx.moveTo(x, 0)
      ctx.lineTo(x, height)
      ctx.stroke()
    }

    // Horizontal grid lines
    for (let y = 0; y < height; y += scale) {
      ctx.beginPath()
      ctx.moveTo(0, y)
      ctx.lineTo(width, y)
      ctx.stroke()
    }

    // Draw axes
    ctx.strokeStyle = "#374151"
    ctx.lineWidth = 2

    const originX = width / 2 + centerX * scale
    const originY = height / 2 - centerY * scale

    // X-axis
    if (originY >= 0 && originY <= height) {
      ctx.beginPath()
      ctx.moveTo(0, originY)
      ctx.lineTo(width, originY)
      ctx.stroke()
    }

    // Y-axis
    if (originX >= 0 && originX <= width) {
      ctx.beginPath()
      ctx.moveTo(originX, 0)
      ctx.lineTo(originX, height)
      ctx.stroke()
    }

    // Draw axis labels
    ctx.fillStyle = "#374151"
    ctx.font = "12px sans-serif"
    ctx.textAlign = "center"

    // X-axis labels
    if (originY >= 0 && originY <= height) {
      for (let i = -20; i <= 20; i++) {
        if (i === 0) continue
        const x = originX + i * scale
        if (x >= 0 && x <= width) {
          ctx.fillText(i.toString(), x, originY + 15)
        }
      }
    }

    // Y-axis labels
    ctx.textAlign = "right"
    if (originX >= 0 && originX <= width) {
      for (let i = -15; i <= 15; i++) {
        if (i === 0) continue
        const y = originY - i * scale
        if (y >= 0 && y <= height) {
          ctx.fillText(i.toString(), originX - 5, y + 4)
        }
      }
    }

    // Draw functions
    functions.forEach((func) => {
      if (!func.visible) return

      ctx.strokeStyle = func.color
      ctx.lineWidth = 2
      ctx.beginPath()

      let firstPoint = true
      for (let pixelX = 0; pixelX < width; pixelX += 2) {
        const mathX = (pixelX - originX) / scale
        const mathY = evaluateExpression(func.expression, mathX)

        if (!isNaN(mathY) && isFinite(mathY)) {
          const pixelY = originY - mathY * scale

          if (pixelY >= -100 && pixelY <= height + 100) {
            if (firstPoint) {
              ctx.moveTo(pixelX, pixelY)
              firstPoint = false
            } else {
              ctx.lineTo(pixelX, pixelY)
            }
          } else {
            firstPoint = true
          }
        } else {
          firstPoint = true
        }
      }

      ctx.stroke()
    })
  }

  const addFunction = () => {
    if (newFunction.trim()) {
      const newFunc: GraphFunction = {
        id: Date.now().toString(),
        expression: newFunction.trim(),
        color: colors[functions.length % colors.length],
        visible: true,
      }
      setFunctions([...functions, newFunc])
      setNewFunction("")
    }
  }

  const removeFunction = (id: string) => {
    setFunctions(functions.filter((f) => f.id !== id))
  }

  const toggleVisibility = (id: string) => {
    setFunctions(functions.map((f) => (f.id === id ? { ...f, visible: !f.visible } : f)))
  }

  const resetView = () => {
    setScale(20)
    setCenterX(0)
    setCenterY(0)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/tools">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <div className="flex items-center space-x-2">
                <BarChart3 className="h-6 w-6 text-blue-600" />
                <span className="text-xl font-bold text-gray-900">YF MATH Graphing Tool</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Controls Panel */}
          <div className="lg:col-span-1 space-y-6">
            {/* Add Function */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Add Function</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="function">Function (in terms of x):</Label>
                  <Input
                    id="function"
                    value={newFunction}
                    onChange={(e) => setNewFunction(e.target.value)}
                    placeholder="e.g., x^2, sin(x), 2*x + 1"
                    onKeyPress={(e) => e.key === "Enter" && addFunction()}
                  />
                </div>
                <Button onClick={addFunction} className="w-full">
                  Add Function
                </Button>
              </CardContent>
            </Card>

            {/* Function List */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Functions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {functions.map((func) => (
                  <div key={func.id} className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                    <div className="w-4 h-4 rounded" style={{ backgroundColor: func.color }} />
                    <span className="flex-1 font-mono text-sm">{func.expression}</span>
                    <Button size="sm" variant="ghost" onClick={() => toggleVisibility(func.id)}>
                      {func.visible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => removeFunction(func.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* View Controls */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">View Controls</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="scale">Zoom:</Label>
                  <Input
                    id="scale"
                    type="range"
                    min="5"
                    max="50"
                    value={scale}
                    onChange={(e) => setScale(Number(e.target.value))}
                  />
                  <div className="text-sm text-gray-600 text-center">{scale}px per unit</div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label htmlFor="centerX">Center X:</Label>
                    <Input
                      id="centerX"
                      type="number"
                      value={centerX}
                      onChange={(e) => setCenterX(Number(e.target.value))}
                      step="0.5"
                    />
                  </div>
                  <div>
                    <Label htmlFor="centerY">Center Y:</Label>
                    <Input
                      id="centerY"
                      type="number"
                      value={centerY}
                      onChange={(e) => setCenterY(Number(e.target.value))}
                      step="0.5"
                    />
                  </div>
                </div>
                <Button onClick={resetView} variant="outline" className="w-full bg-transparent">
                  Reset View
                </Button>
              </CardContent>
            </Card>

            {/* Examples */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Example Functions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {["x^2", "sin(x)", "cos(x)", "x^3 - 2*x", "sqrt(x)", "1/x", "abs(x)", "x^2 - 4*x + 3"].map(
                  (example) => (
                    <Button
                      key={example}
                      variant="ghost"
                      size="sm"
                      className="w-full justify-start font-mono text-xs"
                      onClick={() => setNewFunction(example)}
                    >
                      {example}
                    </Button>
                  ),
                )}
              </CardContent>
            </Card>
          </div>

          {/* Graph Canvas */}
          <div className="lg:col-span-3">
            <Card>
              <CardHeader>
                <CardTitle>Graph</CardTitle>
              </CardHeader>
              <CardContent>
                <canvas
                  ref={canvasRef}
                  width={800}
                  height={600}
                  className="border border-gray-300 rounded-lg w-full max-w-full"
                  style={{ maxHeight: "600px" }}
                />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
