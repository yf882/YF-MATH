"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"
import { BookOpen, Calculator, BarChart3, PieChart, Edit, Plus, Trash2, LogOut } from "lucide-react"
import Link from "next/link"

export default function AdminPage() {
  const { toast } = useToast()
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [activeTab, setActiveTab] = useState("lessons")

  // Content management state
  const [lessons, setLessons] = useState([
    {
      id: 1,
      title: "Introduction to Linear Equations",
      category: "algebra",
      difficulty: "Beginner",
      published: true,
    },
    {
      id: 2,
      title: "Quadratic Equations and Formulas",
      category: "algebra",
      difficulty: "Intermediate",
      published: true,
    },
    {
      id: 3,
      title: "Basic Geometric Shapes",
      category: "geometry",
      difficulty: "Beginner",
      published: true,
    },
    {
      id: 4,
      title: "Pythagorean Theorem",
      category: "geometry",
      difficulty: "Beginner",
      published: true,
    },
    {
      id: 5,
      title: "Introduction to Derivatives",
      category: "calculus",
      difficulty: "Advanced",
      published: true,
    },
    {
      id: 6,
      title: "Descriptive Statistics",
      category: "statistics",
      difficulty: "Intermediate",
      published: true,
    },
  ])

  const [tools] = useState([
    { id: 1, name: "Scientific Calculator", icon: Calculator, path: "/calculator" },
    { id: 2, name: "Equation Solver", icon: BookOpen, path: "/equation-solver" },
    { id: 3, name: "Graphing Tool", icon: BarChart3, path: "/graphing" },
    { id: 4, name: "Statistics Calculator", icon: PieChart, path: "/statistics" },
  ])

  // Check if user is authenticated on page load
  useEffect(() => {
    const checkAuth = () => {
      const user = localStorage.getItem("yfmath_user")
      if (user) {
        try {
          const userData = JSON.parse(user)
          if (userData.email === "lecleccomp@gmail.com" && userData.role === "admin") {
            setIsAuthenticated(true)
          } else {
            router.push("/")
          }
        } catch (e) {
          router.push("/")
        }
      }
      setIsLoading(false)
    }

    checkAuth()
  }, [router])

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const response = await fetch("/api/auth", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      })

      const data = await response.json()

      if (data.success) {
        localStorage.setItem("yfmath_user", JSON.stringify(data.user))
        setIsAuthenticated(true)
        toast({
          title: "Login successful",
          description: "Welcome to the YF MATH admin panel",
        })
      } else {
        toast({
          title: "Login failed",
          description: data.message,
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An error occurred during login",
        variant: "destructive",
      })
    }

    setIsLoading(false)
  }

  const handleLogout = () => {
    localStorage.removeItem("yfmath_user")
    setIsAuthenticated(false)
    toast({
      title: "Logged out",
      description: "You have been logged out successfully",
    })
  }

  const toggleLessonStatus = (id: number) => {
    setLessons(lessons.map((lesson) => (lesson.id === id ? { ...lesson, published: !lesson.published } : lesson)))

    toast({
      title: "Status updated",
      description: "Lesson status has been updated",
    })
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center mx-auto mb-4">
              <span className="text-white font-bold text-lg">YF</span>
            </div>
            <CardTitle className="text-2xl">Admin Login</CardTitle>
            <CardDescription>Access restricted to authorized personnel only</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="lecleccomp@gmail.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? "Logging in..." : "Login"}
              </Button>
            </form>
            <div className="mt-4 text-center">
              <Link href="/" className="text-sm text-blue-600 hover:underline">
                Return to homepage
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">YF</span>
              </div>
              <span className="text-2xl font-bold text-gray-900">YF MATH Admin</span>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-sm text-gray-600">
                Logged in as: <span className="font-medium">lecleccomp@gmail.com</span>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={handleLogout}
                className="flex items-center gap-2 bg-transparent"
              >
                <LogOut className="h-4 w-4" />
                Logout
              </Button>
              <Link href="/">
                <Button variant="ghost" size="sm">
                  View Site
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Content Management System</h1>
          <p className="text-gray-600">
            Manage all YF MATH content from this central dashboard. Only authorized administrators
            (lecleccomp@gmail.com) can access this area.
          </p>
        </div>

        <Tabs defaultValue="lessons" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid grid-cols-3 w-full max-w-md">
            <TabsTrigger value="lessons">Lessons</TabsTrigger>
            <TabsTrigger value="tools">Tools</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="lessons" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-bold">Manage Lessons</h2>
              <Button className="flex items-center gap-2">
                <Plus className="h-4 w-4" />
                Add New Lesson
              </Button>
            </div>

            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-4">Title</th>
                        <th className="text-left p-4">Category</th>
                        <th className="text-left p-4">Difficulty</th>
                        <th className="text-left p-4">Status</th>
                        <th className="text-right p-4">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {lessons.map((lesson) => (
                        <tr key={lesson.id} className="border-b hover:bg-gray-50">
                          <td className="p-4">{lesson.title}</td>
                          <td className="p-4 capitalize">{lesson.category}</td>
                          <td className="p-4">{lesson.difficulty}</td>
                          <td className="p-4">
                            <span
                              className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                lesson.published ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"
                              }`}
                            >
                              {lesson.published ? "Published" : "Draft"}
                            </span>
                          </td>
                          <td className="p-4 text-right">
                            <div className="flex justify-end gap-2">
                              <Button variant="ghost" size="sm">
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button
                                variant={lesson.published ? "outline" : "default"}
                                size="sm"
                                onClick={() => toggleLessonStatus(lesson.id)}
                              >
                                {lesson.published ? "Unpublish" : "Publish"}
                              </Button>
                              <Button variant="ghost" size="sm">
                                <Trash2 className="h-4 w-4 text-red-500" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tools" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-bold">Manage Tools</h2>
              <Button className="flex items-center gap-2">
                <Plus className="h-4 w-4" />
                Add New Tool
              </Button>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {tools.map((tool) => {
                const Icon = tool.icon
                return (
                  <Card key={tool.id}>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <div className="flex items-center gap-2">
                          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                            <Icon className="h-5 w-5 text-blue-600" />
                          </div>
                          <CardTitle className="text-lg">{tool.name}</CardTitle>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="flex justify-between items-center">
                        <Link href={tool.path} target="_blank" className="text-sm text-blue-600 hover:underline">
                          View Tool
                        </Link>
                        <Button variant="outline" size="sm">
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </TabsContent>

          <TabsContent value="settings" className="space-y-4">
            <h2 className="text-xl font-bold">Site Settings</h2>

            <Card>
              <CardHeader>
                <CardTitle>General Settings</CardTitle>
                <CardDescription>Configure general settings for the YF MATH platform</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="site-title">Site Title</Label>
                  <Input id="site-title" defaultValue="YF MATH - Simplify Your Math Journey" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="site-description">Site Description</Label>
                  <Input
                    id="site-description"
                    defaultValue="YF MATH is your integrated online platform for mastering mathematics."
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="contact-email">Contact Email</Label>
                  <Input id="contact-email" defaultValue="lecleccomp@gmail.com" />
                </div>
                <Button>Save Settings</Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Admin Account</CardTitle>
                <CardDescription>Manage your admin account settings</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="admin-email">Admin Email</Label>
                  <Input id="admin-email" value="lecleccomp@gmail.com" disabled />
                  <p className="text-xs text-gray-500 mt-1">This email is the only authorized admin account</p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="admin-password">Change Password</Label>
                  <Input id="admin-password" type="password" placeholder="Enter new password" />
                </div>
                <Button>Update Password</Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
