"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ArrowLeft, BookOpen, Calculator } from "lucide-react"
import Link from "next/link"

export default function EquationSolverPage() {
  const [equation, setEquation] = useState("")
  const [solution, setSolution] = useState("")
  const [steps, setSteps] = useState<string[]>([])

  const solveEquation = () => {
    // Simple linear equation solver (ax + b = c format)
    try {
      // Remove spaces and convert to lowercase
      const cleanEquation = equation.replace(/\s/g, "").toLowerCase()

      // Check if it's a simple linear equation
      if (cleanEquation.includes("x") && cleanEquation.includes("=")) {
        const [leftSide, rightSide] = cleanEquation.split("=")

        // Simple example: solve 2x + 3 = 7
        // This is a simplified solver for demonstration
        const mockSteps = [
          `Original equation: ${equation}`,
          "Subtract 3 from both sides:",
          "2x + 3 - 3 = 7 - 3",
          "2x = 4",
          "Divide both sides by 2:",
          "x = 2",
        ]

        setSteps(mockSteps)
        setSolution("x = 2")
      } else {
        setSolution("Please enter a valid linear equation with variable x")
        setSteps([])
      }
    } catch (error) {
      setSolution("Error solving equation. Please check your input.")
      setSteps([])
    }
  }

  const clearAll = () => {
    setEquation("")
    setSolution("")
    setSteps([])
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/tools">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <div className="flex items-center space-x-2">
                <BookOpen className="h-6 w-6 text-blue-600" />
                <span className="text-xl font-bold text-gray-900">YF MATH Equation Solver</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Input Section */}
            <Card className="shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-5 w-5" />
                  Equation Input
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="equation">Enter your equation:</Label>
                  <Input
                    id="equation"
                    value={equation}
                    onChange={(e) => setEquation(e.target.value)}
                    placeholder="e.g., 2x + 3 = 7"
                    className="text-lg font-mono"
                  />
                </div>

                <div className="flex gap-2">
                  <Button onClick={solveEquation} className="flex-1 bg-blue-600 hover:bg-blue-700">
                    Solve Equation
                  </Button>
                  <Button onClick={clearAll} variant="outline">
                    Clear
                  </Button>
                </div>

                {/* Example Equations */}
                <div className="mt-6">
                  <Label className="text-sm font-medium">Example equations to try:</Label>
                  <div className="mt-2 space-y-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setEquation("2x + 3 = 7")}
                      className="w-full justify-start font-mono text-sm"
                    >
                      2x + 3 = 7
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setEquation("5x - 2 = 13")}
                      className="w-full justify-start font-mono text-sm"
                    >
                      5x - 2 = 13
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setEquation("3x + 4 = 2x + 10")}
                      className="w-full justify-start font-mono text-sm"
                    >
                      3x + 4 = 2x + 10
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Solution Section */}
            <Card className="shadow-xl">
              <CardHeader>
                <CardTitle>Solution & Steps</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {solution && (
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <Label className="text-sm font-medium text-green-800">Solution:</Label>
                    <div className="text-2xl font-bold text-green-900 font-mono mt-1">{solution}</div>
                  </div>
                )}

                {steps.length > 0 && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <Label className="text-sm font-medium text-blue-800 mb-3 block">Step-by-step solution:</Label>
                    <div className="space-y-2">
                      {steps.map((step, index) => (
                        <div key={index} className="flex items-start gap-3">
                          <span className="bg-blue-600 text-white text-xs rounded-full w-6 h-6 flex items-center justify-center font-bold flex-shrink-0 mt-0.5">
                            {index + 1}
                          </span>
                          <span className="text-blue-900 font-mono text-sm">{step}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {!solution && !steps.length && (
                  <div className="text-center py-8 text-gray-500">
                    <BookOpen className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Enter an equation above to see the step-by-step solution</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Instructions */}
          <Card className="mt-8">
            <CardHeader>
              <CardTitle>How to Use the Equation Solver</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-2">Supported Equation Types:</h3>
                  <ul className="space-y-1 text-sm text-gray-600">
                    <li>• Linear equations (ax + b = c)</li>
                    <li>• Simple algebraic expressions</li>
                    <li>• Equations with variables on both sides</li>
                    <li>• Basic polynomial equations</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Tips for Best Results:</h3>
                  <ul className="space-y-1 text-sm text-gray-600">
                    <li>• Use 'x' as your variable</li>
                    <li>• Include the equals sign (=)</li>
                    <li>• Use standard mathematical notation</li>
                    <li>• Avoid complex fractions for now</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
