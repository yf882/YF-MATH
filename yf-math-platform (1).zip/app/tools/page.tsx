import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Calculator, BookOpen, BarChart3, PieChart, ArrowLeft, TrendingUp } from "lucide-react"
import Link from "next/link"

export default function ToolsPage() {
  const tools = [
    {
      title: "Scientific Calculator",
      description: "Advanced calculator with trigonometric, logarithmic, and statistical functions.",
      icon: Calculator,
      href: "/calculator",
      color: "blue",
    },
    {
      title: "Equation Solver",
      description: "Step-by-step solutions for algebraic equations, systems, and inequalities.",
      icon: BookOpen,
      href: "/equation-solver",
      color: "indigo",
    },
    {
      title: "Graphing Tool",
      description: "Visualize functions, plot data points, and explore mathematical relationships.",
      icon: BarChart3,
      href: "/graphing",
      color: "purple",
    },
    {
      title: "Statistics Calculator",
      description: "Calculate mean, median, mode, standard deviation, and other statistical measures.",
      icon: PieChart,
      href: "/statistics",
      color: "green",
    },
    {
      title: "Matrix Calculator",
      description: "Perform matrix operations including multiplication, determinants, and inverses.",
      icon: TrendingUp,
      href: "/matrix",
      color: "orange",
    },
    {
      title: "Unit Converter",
      description: "Convert between different units of measurement for length, weight, volume, and more.",
      icon: Calculator,
      href: "/converter",
      color: "red",
    },
  ]

  const getColorClasses = (color: string) => {
    const colorMap = {
      blue: "bg-blue-100 text-blue-600",
      indigo: "bg-indigo-100 text-indigo-600",
      purple: "bg-purple-100 text-purple-600",
      green: "bg-green-100 text-green-600",
      orange: "bg-orange-100 text-orange-600",
      red: "bg-red-100 text-red-600",
    }
    return colorMap[color as keyof typeof colorMap] || "bg-gray-100 text-gray-600"
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">YF</span>
                </div>
                <span className="text-xl font-bold text-gray-900">Math Tools</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Interactive Math Tools</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Explore our comprehensive suite of mathematical tools designed to make problem-solving easier and more
            intuitive.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {tools.map((tool, index) => {
            const Icon = tool.icon
            return (
              <Card key={index} className="hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
                <CardHeader>
                  <div
                    className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${getColorClasses(tool.color)}`}
                  >
                    <Icon className="h-8 w-8" />
                  </div>
                  <CardTitle className="text-center">{tool.title}</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <CardDescription className="mb-6">{tool.description}</CardDescription>
                  <Link href={tool.href}>
                    <Button className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                      Launch Tool
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Coming Soon Section */}
        <div className="mt-16 text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">More Tools Coming Soon</h2>
          <p className="text-gray-600 mb-8">
            We're constantly expanding our toolkit to provide you with the best mathematical learning experience.
          </p>
          <div className="grid md:grid-cols-3 gap-4 max-w-2xl mx-auto">
            <div className="bg-white/50 rounded-lg p-4 border-2 border-dashed border-gray-300">
              <h3 className="font-semibold text-gray-700">Calculus Helper</h3>
              <p className="text-sm text-gray-500">Derivatives & Integrals</p>
            </div>
            <div className="bg-white/50 rounded-lg p-4 border-2 border-dashed border-gray-300">
              <h3 className="font-semibold text-gray-700">Geometry Tools</h3>
              <p className="text-sm text-gray-500">Area & Volume Calculator</p>
            </div>
            <div className="bg-white/50 rounded-lg p-4 border-2 border-dashed border-gray-300">
              <h3 className="font-semibold text-gray-700">Probability Simulator</h3>
              <p className="text-sm text-gray-500">Interactive Experiments</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
